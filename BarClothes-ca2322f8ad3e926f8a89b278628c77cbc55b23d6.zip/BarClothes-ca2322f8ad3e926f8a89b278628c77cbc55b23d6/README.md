# BarClothes

## What is __BarClothes__?

__BarClothes__, a middleman clothes e-marketing has established in July, 2017. BarClothes is the place that customers and sellers meet like Amazon, Kaidee, Ebay.

